import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import multer from "multer";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Wait to initialize Gemini API until needed
  let ai: GoogleGenAI | null = null;
  const getAiClient = () => {
    if (!ai) {
      if (!process.env.GEMINI_API_KEY) {
        throw new Error("GEMINI_API_KEY environment variable is required.");
      }
      ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    }
    return ai;
  };

  const storage = multer.diskStorage({
    destination: (req, file, cb) => {
      const category = req.params.category;
      // Sanitize category to prevent traversal
      const safeCategory = path.basename(category);
      const dir = path.join(process.cwd(), "uploads", safeCategory);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      cb(null, dir);
    },
    filename: (req, file, cb) => {
      cb(null, file.originalname);
    }
  });
  const upload = multer({ storage });

  app.post("/api/documents/:category", upload.single("file"), (req, res) => {
    res.json({ success: true, filename: req.file?.originalname });
  });

  app.get("/api/documents/:category", (req, res) => {
    const category = req.params.category;
    const safeCategory = path.basename(category);
    const dir = path.join(process.cwd(), "uploads", safeCategory);
    if (!fs.existsSync(dir)) return res.json({ files: [] });
    const files = fs.readdirSync(dir).map(name => {
      const stat = fs.statSync(path.join(dir, name));
      return { name, size: stat.size, date: stat.mtime };
    });
    res.json({ files });
  });

  app.delete("/api/documents/:category/:filename", (req, res) => {
    const category = req.params.category;
    const safeCategory = path.basename(category);
    const filename = path.basename(req.params.filename);
    const filepath = path.join(process.cwd(), "uploads", safeCategory, filename);
    if (fs.existsSync(filepath)) {
      fs.unlinkSync(filepath);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: "File not found" });
    }
  });

  // Chat completion endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages } = req.body;
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: "Invalid messages array." });
      }

      const client = getAiClient();
      
      // Load system instructions from AGENTS.md
      const agentsMdPath = path.join(process.cwd(), "AGENTS.md");
      let systemInstruction = "";
      if (fs.existsSync(agentsMdPath)) {
        systemInstruction = fs.readFileSync(agentsMdPath, "utf-8");
      }

      // Load uploaded context from plain text files
      const uploadsDir = path.join(process.cwd(), "uploads");
      let uploadedContext = "";
      if (fs.existsSync(uploadsDir)) {
        const categories = fs.readdirSync(uploadsDir);
        for (const cat of categories) {
          const catDir = path.join(uploadsDir, cat);
          if (fs.statSync(catDir).isDirectory()) {
            const files = fs.readdirSync(catDir);
            for (const file of files) {
              if (file.match(/\.(txt|md|csv|json)$/i)) {
                try {
                  const content = fs.readFileSync(path.join(catDir, file), "utf-8");
                  // Limit the size logically (or just include it)
                  uploadedContext += `\n\n--- Document: ${cat}/${file} ---\n${content}\n`;
                } catch (e) {
                  // ignore failing file read
                }
              }
            }
          }
        }
      }

      if (uploadedContext) {
        systemInstruction += `\n\n# User Provided Documents\nThe following documents have been uploaded and are available as context:\n${uploadedContext}`;
      }

      // Convert messages for the Interaction API format 
      // where system instructions are supported at model config level
      const formattedHistory = messages.slice(0, -1).map((m: any) => ({
        role: m.role === "user" ? "user" : "model",
        parts: [{ text: m.content }]
      }));
      
      const latestMessage = messages[messages.length - 1].content;

      const chat = client.chats.create({
        model: "gemini-2.5-pro",
        config: {
          systemInstruction,
          temperature: 0.2, // Low temperature for factual, sharp responses
        },
        history: formattedHistory,
      });

      const response = await chat.sendMessage({ message: latestMessage });
      
      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Chat API Error:", error);
      res.status(500).json({ error: error.message || "Failed to process chat query." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
