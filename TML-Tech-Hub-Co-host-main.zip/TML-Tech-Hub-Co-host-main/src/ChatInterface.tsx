import React, { useState, useRef, useEffect } from 'react';
import { Send, Terminal, Loader2, User, Trash2 } from 'lucide-react';
import Markdown from 'react-markdown';

type Message = {
  id: string;
  role: 'user' | 'assistant';
  content: string;
};

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'initial',
      role: 'assistant',
      content: 'Awaiting executive input. Let me know if we are mapping out the new Hospital Management System schema, drafting a logistics network proposal, or diagnosing an AppSheet type mismatch.'
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Create request messages mapping
      const apiMessages = [...messages, userMessage].map((m) => ({
        role: m.role,
        content: m.content
      }));

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: apiMessages })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to fetch response');
      }

      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: data.text
      }]);
    } catch (error) {
      console.error(error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'assistant',
        content: `**Error:** Unable to connect to the agent server. Please check the logs. (${error instanceof Error ? error.message : "Unknown Error"})`
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClearHistory = () => {
    setMessages([
      {
        id: 'initial',
        role: 'assistant',
        content: 'Awaiting executive input. Let me know if we are mapping out the new Hospital Management System schema, drafting a logistics network proposal, or diagnosing an AppSheet type mismatch.'
      }
    ]);
  };

  return (
    <div className="flex flex-col border border-slate-800 bg-slate-900/40 rounded-xl overflow-hidden backdrop-blur-sm h-[500px]">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center">
          <Terminal className="w-5 h-5 text-purple-400 mr-2" />
          <span className="text-sm font-medium text-slate-300 font-mono">TML_CO_PILOT_TERMINAL_V1</span>
        </div>
        <button 
          onClick={handleClearHistory}
          className="text-slate-400 hover:text-red-400 transition-colors p-1.5 rounded-md hover:bg-red-500/10"
          title="Clear History"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex max-w-3xl ${msg.role === 'user' ? 'ml-auto' : ''}`}>
            {msg.role === 'assistant' && (
              <div className="flex-shrink-0 mr-4">
                <div className="w-8 h-8 rounded-md bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
                  <Terminal className="w-4 h-4 text-purple-400" />
                </div>
              </div>
            )}
            
            <div className={`flex-1 rounded-lg px-4 py-3 ${
              msg.role === 'user' 
                ? 'bg-emerald-500/10 text-emerald-100 border border-emerald-500/20' 
                : 'bg-slate-800/50 text-slate-300 border border-slate-700/50'
            }`}>
              <div className="prose prose-invert prose-sm max-w-none text-sm leading-relaxed" style={{ color: 'inherit' }}>
                <Markdown>{msg.content}</Markdown>
              </div>
            </div>

            {msg.role === 'user' && (
              <div className="flex-shrink-0 ml-4">
                <div className="w-8 h-8 rounded-md bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                  <User className="w-4 h-4 text-emerald-400" />
                </div>
              </div>
            )}
          </div>
        ))}
        
        {isLoading && (
          <div className="flex max-w-3xl">
            <div className="flex-shrink-0 mr-4">
              <div className="w-8 h-8 rounded-md bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
                <Terminal className="w-4 h-4 text-purple-400" />
              </div>
            </div>
            <div className="flex-1 rounded-lg px-4 py-3 bg-slate-800/50 border border-slate-700/50 flex flex-col justify-center">
               <div className="flex items-center text-slate-400 text-sm">
                 <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                 Processing query...
               </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 bg-slate-900 border-t border-slate-800">
        <form onSubmit={handleSubmit} className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            disabled={isLoading}
            placeholder="Type your instruction or architectural query..."
            className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-4 pr-12 py-3 text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-purple-500 focus:border-purple-500 transition-colors"
          />
          <button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="absolute right-2 p-2 text-slate-400 hover:text-purple-400 disabled:opacity-50 disabled:hover:text-slate-400 transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
