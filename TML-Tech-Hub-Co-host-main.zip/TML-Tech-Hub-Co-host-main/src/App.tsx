/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useState } from "react";
import { Terminal, Database, Cpu, FileText } from "lucide-react";
import ChatInterface from "./ChatInterface";
import FolderManager from "./FolderManager";

export default function App() {
  const [activeCategory, setActiveCategory] = useState<{ id: string; title: string } | null>(null);

  return (
    <div className="min-h-screen bg-[#0A0A0A] text-slate-300 font-sans p-8 flex flex-col items-center justify-center">
      <div className="max-w-4xl w-full">
        <header className="mb-12 border-b border-slate-800 pb-8 flex items-end justify-between">
          <div>
            <h1 className="text-3xl font-medium tracking-tight text-white mb-2">TML Tech Hub Co-Pilot</h1>
            <p className="text-sm font-mono text-slate-500">SYSTEM ARCHITECTURE & OPERATIONS — INTERNAL ONLY</p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            SYSTEMS ONLINE
          </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {/* Engineering & Architecture */}
          <div 
            onClick={() => setActiveCategory({ id: 'architecture', title: 'Architecture' })}
            className="cursor-pointer bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-slate-600 transition-colors"
          >
            <div className="w-10 h-10 rounded bg-blue-500/10 flex items-center justify-center mb-4">
              <Database className="w-5 h-5 text-blue-400" />
            </div>
            <h2 className="text-sm font-medium text-white mb-2">Architecture</h2>
            <p className="text-xs text-slate-400">Database schemas, Google Apps Script, AppSheet debugging.</p>
          </div>

          {/* Hardware & Inventory */}
          <div 
            onClick={() => setActiveCategory({ id: 'hardware', title: 'Hardware' })}
            className="cursor-pointer bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-slate-600 transition-colors"
          >
            <div className="w-10 h-10 rounded bg-orange-500/10 flex items-center justify-center mb-4">
              <Cpu className="w-5 h-5 text-orange-400" />
            </div>
            <h2 className="text-sm font-medium text-white mb-2">Hardware</h2>
            <p className="text-xs text-slate-400">Ryzen & Radeon specs, logistics tracking, performance marketing.</p>
          </div>

          {/* Business Development */}
          <div 
            onClick={() => setActiveCategory({ id: 'proposals', title: 'Proposals' })}
            className="cursor-pointer bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-slate-600 transition-colors"
          >
            <div className="w-10 h-10 rounded bg-emerald-500/10 flex items-center justify-center mb-4">
              <FileText className="w-5 h-5 text-emerald-400" />
            </div>
            <h2 className="text-sm font-medium text-white mb-2">Proposals</h2>
            <p className="text-xs text-slate-400">B2B proposals, IT servicing, logistics corridors infrastructure.</p>
          </div>

          {/* Core Access */}
          <div 
            onClick={() => setActiveCategory({ id: 'operations', title: 'Operations' })}
            className="cursor-pointer bg-slate-900/50 border border-slate-800 rounded-lg p-6 hover:border-slate-600 transition-colors"
          >
            <div className="w-10 h-10 rounded bg-purple-500/10 flex items-center justify-center mb-4">
              <Terminal className="w-5 h-5 text-purple-400" />
            </div>
            <h2 className="text-sm font-medium text-white mb-2">Operations</h2>
            <p className="text-xs text-slate-400">Executive Chief of Staff terminal & direct systems interaction.</p>
          </div>
        </div>

        <ChatInterface />
      </div>

      {activeCategory && (
        <FolderManager 
          category={activeCategory.id}
          categoryTitle={activeCategory.title}
          onClose={() => setActiveCategory(null)}
        />
      )}
    </div>
  );
}
